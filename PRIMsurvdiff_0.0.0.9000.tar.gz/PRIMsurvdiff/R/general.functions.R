#' @import survival
NULL
#' @import Hmisc
NULL
#' @import parallel
NULL


#' Identify Survival Differences for Randomized Clinical Trials using PRIM 
#' 
#' Find subgroups of the input 2-arm clinical trial where the treatment group has a statistically significantly better outcome than the control group. 
#' @param event.var Indicator variable for the event.
#' @param time.var Time to event or censure
#' @param x Matrix of variables under consideration for creating subgroups
#' @param sig.level Significance level (default = 0.05)
#' @param support Minimum fraction of follow-up time for observations under consideration that must be in a subgroup 
#' @param nsplits Maximum number of subgroups to create (default =20)
#' @param ncov Number of variables used to create each term that defines a subgroup (limited to 1 or 2)
#' @param iter Number of bootstrapped permutations to be run to assess the significance of each term (default = 1000)
#' @param cut.points Named list given to specify thresholds for continuous variable stratification. If null a continuous variable is categorized using thresholds (default = NULL)
#' @param is.ordinal Indicator variable specifiying which column in \code{x} should be considered ordinal. If null, all variables are considered nominal(default = NULL)
#' @param tmp.path Directory to store all intermediary files
#' @param trt.var Indicator variable for treatment group (1= treatment 0 = control)
#' @param max.hr Maximum hazard ratio for outputted subgroup(default = 1000)
#' @param clust Cluster object created from parallel package
#' @return print.peel: Peeling terms used to create partitions
#' @return print.paste: Pasting terms used to create partitions
#' @return p.peel: P-values for peeling terms used to create partitions
#' @return p.paste: P-values for pasting terms used to create partitions
#' @return iidd.out: Subgroup identifier
#' @return haz: Hazard ratio for each subgroup
#' @examples
#' \dontrun{
#' library(speff2trial)
#' d=ACTG175[which(ACTG175$arms %in% c(0,1)),]
#' vars=c('age','wtkg',"cd40","cd80",'hemo','homo','race','gender','karnof','oprior')
#' for (i in 5:length(vars)) d[,vars[i]]=factor(d[,vars[i]])
#' d$karnof=factor(d$karnof)
#' d$cd40=log(d$cd40+1)
#' d$cd80=log(d$cd80+1)
#' g=PRIMsurvdiffCPM(event.var=d$cens,time.var=d$days/365.25,x=d[,vars],sig.level=.1,
#' support=.24,nsplits=20,ncov=1,cut.points=list('age'=c(30,40,50),'wtkg'=c(60,70,80)),
#' is.ordinal=c(T,T,F,F,F,F,T,F,T,T,T,T,T),tmp.path='/test/PrimSurv/b/',trt.var=d$arms)
#' }
#' @export

PRIMsurvdiffCPM=function(event.var,time.var,x,sig.level=0.05,support,nsplits=20,ncov=1,iter=1000,
 cut.points=list(NULL),is.ordinal=NULL,tmp.path='D:/temp/PrimSurv/',trt.var,max.hr=1000,clust=NULL)
{
  options(warn=-1)
 
  dir.create(tmp.path,recursive=TRUE)

  if (is.null(is.ordinal)) is.ordinal=rep(F,ncol(x))

  is.cate=rep(NA,ncol(x))
  for (i in 1:ncol(x)) is.cate[i]=is.factor(x[,i])

 #identify cutpoint for continuous predictors treated as ordinal
  id=which(colnames(x) %in% names(cut.points))

  if (length(id)==0) check.cuts=which(!is.cate)
  if (length(id)>0) check.cuts=which(!is.cate) %w/o% id

  if (length(check.cuts)>0)
  {
    for (i in check.cuts)
    {
       eval(parse(text=paste('cut.points$',colnames(x)[i],'=c(',paste(mean(x[,i])+c(-1,0,1)*stats::sd(x[,i]),collapse=','),')',sep='')))
    }
  }

  input.data=x
  if (sum(!is.cate)>0)
  {
    for (i in which(!is.cate))
    {
      input.data[,colnames(x)[i]]=cut(input.data[,colnames(x)[i]],c(-Inf,cut.points[[colnames(x)[i]]],'Inf'))
    }
  }

  if (is.null(clust))
  {
    #utilize cluster if need to compute pvale
    clust=makeCluster(detectCores())
  }

 #construct database

  dat=data.frame('ID'=1:nrow(x),'o.times'=time.var,'event'=event.var,'treat'=trt.var,input.data)

  id.info=rep(NA,ncol(dat))
  for (i in 4:ncol(dat)) id.info[i]=is.factor(dat[,i])

  dat.org<-dat
  # create output storages
  iidd.out<-rep(0,nrow(dat.org))
  text.out.paste=text.out.peel<-matrix('',50,nsplits)
  pvalue.out.peel=pvalue.out.paste=matrix(NA,50,nsplits)

  for (jj in 1:nsplits)
  {
 
    ids.to.use=which(iidd.out==0)
    x<-dat.org[ids.to.use,,drop=FALSE]
    n.needed=support*sum(x$o.times)

    peeling<-peel.PRIMsurvdiff(x,n.needed=n.needed,ncov=ncov,sig.level=sig.level,is.ordinal=is.ordinal,clust=clust,tmp.path=tmp.path,iter=iter,max.hr=max.hr)
    if (is.null(peeling$id.final)) break
    if (!is.null(peeling$id.final))
    {
      pasting<-paste.PRIMsurvdiff(x,ncov=ncov,sig.level=sig.level,is.ordinal=is.ordinal,tmp.path=tmp.path,id.in=peeling$id.final,clust=clust,iter=iter)
      iidd.out[which(dat.org$ID %in% pasting$id.final)]=jj
      text.out.peel[,jj]=peeling$names.final
      text.out.paste[,jj]=pasting$names.final
      pvalue.out.peel[,jj]=peeling$p.value.final
      pvalue.out.paste[,jj]=pasting$p.value.final
    }
  }
  peel.in=apply(pvalue.out.peel,2,function(x) sum(x<sig.level,na.rm=T))
  paste.in=apply(pvalue.out.paste,2,function(x) sum(x<sig.level,na.rm=T))
  if (sum(peel.in)==0)
  {
    print.peel=print.paste=''
    p.peel=p.paste=NA
  }
  if (sum(peel.in)>0)
  {
    for (i in which(peel.in>0))
    {
      if (peel.in[i]<50) text.out.peel[(peel.in[i]+1):nsplits,i]=text.out.peel[(peel.in[i]+1):nsplits,i]=''
      if (peel.in[i]<50) pvalue.out.peel[(peel.in[i]+1):nsplits,i]=pvalue.out.peel[(peel.in[i]+1):nsplits,i]=NA
    }
    print.peel=text.out.peel[1:max(peel.in),which(peel.in>0),drop=F]
    p.peel=pvalue.out.peel[1:max(peel.in),which(peel.in>0),drop=F]

    if (sum(paste.in)==0)
    {
      print.paste=''
      p.paste=NA
    }

    if (sum(paste.in)>0)
    {
      for (i in which(paste.in>0))
      {
        text.out.paste[(paste.in[i]+1):nsplits,i]=text.out.paste[(paste.in[i]+1):nsplits,i]=''
        pvalue.out.paste[(paste.in[i]+1):nsplits,i]=pvalue.out.paste[(paste.in[i]+1):nsplits,i]=NA
      }
      print.paste=text.out.paste[1:max(paste.in),which(peel.in>0),drop=F]
      p.paste=pvalue.out.paste[1:max(paste.in),which(peel.in>0),drop=F]
    }
  }

  if (max(iidd.out)>0)
  {
    haz=matrix(NA,max(iidd.out)+2,5)
    colnames(haz)=c('In_treat','Out_treat','In_ctrl','Out_ctrl','In_HR')
    haz[1,1]=mean(dat.org$event[which(dat.org$treat==1)])/mean(dat.org$o.times[which(dat.org$treat==1)])
    haz[1,3]=mean(dat.org$event[which(dat.org$treat==0)])/mean(dat.org$o.times[which(dat.org$treat==0)])
    k=2
    rownames(haz)=c('Overall',paste('Partition',1:max(iidd.out)),'Remainder')
    for (i in c(1:max(iidd.out),0))
    {
      haz[k,1]=mean(dat.org$event[which(iidd.out==i & dat.org$treat==1)])/mean(dat.org$o.times[which(iidd.out==i & dat.org$treat==1)])
      if (i>0) haz[k,2]=mean(dat.org$event[which((iidd.out>i | iidd.out==0) & dat.org$treat==1)])/mean(dat.org$o.times[which((iidd.out>i | 
      iidd.out==0) & dat.org$treat==1)])
      haz[k,3]=mean(dat.org$event[which(iidd.out==i & dat.org$treat==0)])/mean(dat.org$o.times[which(iidd.out==i & dat.org$treat==0)])
      if (i>0) haz[k,4]=mean(dat.org$event[which((iidd.out>i | iidd.out==0) & dat.org$treat==0)])/mean(dat.org$o.times[which((iidd.out>i | 
      iidd.out==0) & dat.org$treat==0)])
      k=k+1
    }
    haz[,5]=haz[,1]/haz[,3]
  }
  if (max(iidd.out)==0)
  {
    haz=as.matrix(mean(dat.org$event)/mean(dat.org$o.times))
    rownames(haz)='Overall'
    colnames(haz)='All'
  }

  ans=list(print.peel=print.peel,print.paste=print.paste,p.peel=p.peel,p.paste=p.paste,iidd.out=iidd.out,haz=haz)
  return(ans)
  options(warn=0)

}
#' Find elements of one vector that are not in another vector
#' 
#' Find elements of one vector that are not in another vector (taken from the help file documentation for '%in%')
#' @param x A vector.
#' @param y A vector.
#' @return elements of \code{x} not in \code{y}.
#' @examples
#' c(1:10) %w/o% c(2,4,6)
#' LETTERS[1:10] %w/o% c('G','E','R')
#' @export

"%w/o%" <- function(x, y) x[!x %in% y]

#' Create all possible subgroups of size less than or equal to an integer
#' 
#' @param n A integer.
#' @return all possible subgroups of size less than \code{n}.
#' @examples
#' grp.sel(5)
#' @export
grp.sel=function(n) 
{
  out=vector("list",2*(n-1)+1)
  out[[1]]=1
  if (n>2)
  {
    for (i in 2:(n-1))
    {
      out[[i]]=c(out[[i-1]],i)
    }
  }
  out[[n]]=n
  if (n>2)
  {
    for (i in (n+1):(2*(n-1)))
    {
      out[[i]]=c(out[[i-1]],2*n-i)
    }
  }
  out[[2*(n-1)+1]]=1:n
return(out)
}

#' List all possible subgroups of size less than or equal to an integer
#' 
#' List all possible subgroups of size less than or equal to an integer (ordered and unordered)
#' @param n A integer.
#' @return all: a list of all possible subgroups of size less than \code{n}.
#' @return ordered: a list of all ordered possible subgroups of size less than \code{n}.
#' @examples
#' #potent(5)
#' @export
potent=function(n)
{
  if (n==2)
  {
   return(list('all'=matrix(c(1,0),nrow=1),'ordered'=matrix(c(1,0),nrow=1)))
  }
  if (n>2)
  {
    eval(parse(text=paste('x=as.matrix(expand.grid(',paste(rep('c(0,1)',n),collapse=','),'))',sep='')))
    a1=x[2:(nrow(x)/2),,drop=F]
    a2=a1[which(apply(apply(a1,1,diff),2,function(x) sum(x==1))==0),,drop=F]
    return(list('all'=a1,'ordered'=a2))
  }
}

