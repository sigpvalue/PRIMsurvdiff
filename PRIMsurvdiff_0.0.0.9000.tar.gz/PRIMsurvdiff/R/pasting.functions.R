#' Internal wrapper function for pasting variable creation
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param id.in Indiciator variable for observations already in the current partition
#' @param group Variable indicating whether a variable is ordinal or nominal
#' @param use.ids Observations under consideration 
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
pasting.surv.diff.int=function(dat,mean.to.beat,id.in,group,use.ids)
{
  if (group=='ordered') info.=potent(nlevels(factor(dat[use.ids,5])))$ordered
  if (group=='nominal') info.=potent(nlevels(factor(dat[use.ids,5])))$all

  if(is.null(info.))
  {
    best.txt=NULL
    iidd=NULL
    return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
  }
  info.=rbind(info.,1-info.)

  out.info=matrix('',nrow(info.),2)
  out.num=matrix(NA,nrow(info.),1)
  colnames(out.info)=c('IN','OUT')
  colnames(out.num)=c('HR')

  for (ii in 1:nrow(info.))
  {
    in.=levels(factor(dat[use.ids,5]))[which(info.[ii,]==1)]
    out.=levels(factor(dat[use.ids,5]))[which(info.[ii,]==0)]
    out.info[ii,1]=paste(in.,collapse='_')
    out.info[ii,2]=paste(out.,collapse='_')

    var.=rep(NA,nrow(dat))
    var.[intersect(use.ids,which(dat[,5] %in% in.))]=1
    var.[intersect(use.ids,which(dat[,5] %in% out.))]=0
    var.[-use.ids]=0
    var.[which(dat$ID %in% id.in)]=1

    out.num[ii,]=c(sum(dat$event[which(var.==1 & dat$treat==1)])/sum(dat$o.times[which(var.==1 & dat$treat==1)]))/
     (sum(dat$event[which(var.==1 & dat$treat==0)])/sum(dat$o.times[which(var.==1 & dat$treat==0)]))
  }

  out.fin=data.frame(out.info,out.num)

  o=order(out.fin$HR)
  out.fin=out.fin[o,]
  sel=which(out.fin$HR<mean.to.beat)[1]

  if (is.na(sel))
  {
    best.txt=NULL
    iidd=NULL
  }
  if(!is.na(sel))
  {
    iidd=(dat$ID[intersect(use.ids,which(dat[,5] %in% strsplit(as.character(out.fin[sel,1]),"_")[[1]]))]) %w/o% id.in
    best.txt=paste(colnames(dat)[5],'%in%',paste(strsplit(as.character(out.fin[sel,1]),"_")[[1]],collapse=','))
    mean.to.beat=out.fin[sel,3]
  }
  return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}
#' Internal pasting function for pasting term with 2 nominal variables
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param id.in Indiciator variable for observations already in the current partition
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
nom.nom.surv.diff.paste=function(dat,mean.to.beat,id.in)
{
  dat.out=dat[which(dat$ID %in% (dat$ID %w/o% id.in)),]
  dat.in=data.frame(dat[which(dat$ID %in% id.in),],'int'='')
  dat.out$int=factor(paste(dat.out[,5],dat.out[,6],sep='^'))
  levs=levels(dat.out$int)
  info.=potent(nlevels(dat.out$int))$all

  num.ctl.sum=sum(dat.in$event[dat.in$treat==0])
  num.trt.sum=sum(dat.in$event[dat.in$treat==1])
  dem.ctl.sum=sum(dat.in$o.times[dat.in$treat==0])
  dem.trt.sum=sum(dat.in$o.times[dat.in$treat==1])

  if(is.null(info.))
  {
    best.txt=NULL
    iidd=NULL
    return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
  }

  out.info=matrix('',nrow(info.),2)
  out.num=matrix(NA,nrow(info.),2)
  colnames(out.info)=c('IN','OUT')
  colnames(out.num)=c('HR_IN','HR_OUT')

  for (ii in 1:nrow(info.))
  {
    in.=levels(factor(dat.out[,7]))[which(info.[ii,]==1)]
    out.=levels(factor(dat.out[,7]))[which(info.[ii,]==0)]
    out.info[ii,1]=paste(in.,collapse='_')
    out.info[ii,2]=paste(out.,collapse='_')

    var.=rep(NA,nrow(dat.out))
    var.[which(dat.out[,7] %in% in.)]=1
    var.[which(dat.out[,7] %in% out.)]=0

      out.num[ii,]=c(
      ((num.trt.sum+sum(dat.out$event[which(var.==1 & dat.out$treat==1)]))/(dem.trt.sum+sum(dat.out$o.times[which(var.==1 & dat.out$treat==1)])))/
      ((num.ctl.sum+sum(dat.out$event[which(var.==1 & dat.out$treat==0)]))/(dem.ctl.sum+sum(dat.out$o.times[which(var.==1 & dat.out$treat==0)]))),
      ((num.trt.sum+sum(dat.out$event[which(var.==0 & dat.out$treat==1)]))/(dem.trt.sum+sum(dat.out$o.times[which(var.==0 & dat.out$treat==1)])))/
      ((num.ctl.sum+sum(dat.out$event[which(var.==0 & dat.out$treat==0)]))/(dem.ctl.sum+sum(dat.out$o.times[which(var.==0 & dat.out$treat==0)]))))
  }

  out=data.frame(out.info,out.num)

  out.in=out[,sort(c(grep('IN',colnames(out))))]
  out.out=out[,sort(c(grep('OUT',colnames(out))))]

  colnames(out.out)=colnames(out.in)=c('Subset','HR')
  out.fin=rbind(out.in,out.out)

  o=order(out.fin$HR)
  out.fin=out.fin[o,]
  sel=which(out.fin$HR<mean.to.beat)[1]

  if (is.na(sel))
  {
    best.txt=NULL
    iidd=NULL
  }

  if(!is.na(sel))
  {
    iidd=dat.out$ID[which(dat.out[,7] %in% strsplit(as.character(out.fin[sel,1]),"_")[[1]])]
    best.txt=paste(paste(colnames(dat.out)[5:6],collapse='^'),'%in%',paste(strsplit(as.character(out.fin[sel,1]),"_")[[1]],collapse=','))
    mean.to.beat=out.fin[sel,2]
  }
  return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}
#' Internal pasting function for pasting term with 1 nominal and 1 ordinal variable
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param id.in Indiciator variable for observations already in the current partition
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
nom.ord.surv.diff.paste=function(dat,mean.to.beat,id.in)
{
  grouper=grp.sel(nlevels(dat[,6]))
  levs=levels(dat[,6])
  best.txt.store=''
  for (i in 1:length(grouper))
  {
    use.ids=which(dat[,6] %in% levs[grouper[[i]]])
    aa=pasting.surv.diff.int(dat=dat[,-6],mean.to.beat=mean.to.beat,id.in=id.in,group='nominal',use.ids=use.ids)
    if (!is.null(aa$iidd) & aa$mean.to.beat<mean.to.beat)
    {
      iidd.store=sort(aa$iidd)
      best.txt.store=paste(paste(colnames(dat)[6], '%in%',paste(levs[grouper[[i]]],collapse=','),sep=''),"^",aa$best.txt,sep='')
      mean.to.beat=aa$mean.to.beat
    }
  }
  if (best.txt.store=='')
  {
    best.txt.store=NULL
    iidd.store=NULL
  }
  return(list(iidd=iidd.store,best.txt=best.txt.store,mean.to.beat=mean.to.beat))
}
#' Internal pasting function for pasting term with 2 ordinal variables
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param id.in Indiciator variable for observations already in the current partition
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
ord.ord.surv.diff.paste=function(dat,mean.to.beat,id.in)
{
  grouper=grp.sel(nlevels(dat[,6]))
  levs=levels(dat[,6])
  best.txt.store=''
  for (i in 1:length(grouper))
  {
    use.ids=which(dat[,6] %in% levs[grouper[[i]]])
    aa=pasting.surv.diff.int(dat=dat[,-6],mean.to.beat=mean.to.beat,id.in=id.in,group='ordered',use.ids=use.ids)
    if (!is.null(aa$iidd) & aa$mean.to.beat<mean.to.beat)
    {
      iidd.store=sort(aa$iidd)
      best.txt.store=paste(paste(colnames(dat)[6], '%in%',paste(levs[grouper[[i]]],collapse=','),sep=''),"^",aa$best.txt,sep='')
      mean.to.beat=aa$mean.to.beat
    }
  }
  if (best.txt.store=='')
  {
    best.txt.store=NULL
    iidd.store=NULL
  }
  return(list(iidd=iidd.store,best.txt=best.txt.store,mean.to.beat=mean.to.beat))
}
#' Overall pasting function (not to be called)
#' 
#' @param x Matrix of variables under consideration for creating subgroups
#' @param ncov Number of variables used to create each term that defines a subgroup 
#' @param sig.level Significance level (default = 0.05)
#' @param is.ordinal Indicator variable specifiying which column in \code{x} should be considered ordinal.
#' @param clust Cluster object created from parallel package
#' @param tmp.path Directory to store all intermediary files
#' @param id.in Indiciator variable for observations already in the current partition
#' @param iter Number of bootstrapped permutations to be run to assess the significance of each term
#' @return id.final Output subgroups indicator
#' @return names.final Text definition of output subgroups
#' @return p.value.final P-value for output subgroups
#' @export
paste.PRIMsurvdiff<-function(x,ncov,sig.level,is.ordinal,clust,tmp.path,id.in,iter)
{
  names.final<-rep('',50)
  p.value.final<-rep(NA,50)
  id.final=id.in

  # create up to 50 terms
  for (ii in 1:50)
  {
    mean.y.org=mean.y<-(mean(x$event[which(x$treat==1 & x$ID %in% id.in)])/mean(x$o.times[which(x$treat==1& x$ID %in% id.in)]))/
      (mean(x$event[which(x$treat==0 & x$ID %in% id.in)])/mean(x$o.times[which(x$treat==0 & x$ID %in% id.in)]))
    if (ncov==1)
     {
       for (i in 5:ncol(x))
       {
         if (is.ordinal[i-4])  tmp=ord.surv.diff.paste(dat=x[,c(1:4,i)],mean.to.beat=mean.y,id.in=id.in)
         if (!is.ordinal[i-4]) tmp=nom.surv.diff.paste(dat=x[,c(1:4,i)],mean.to.beat=mean.y,id.in=id.in)

         if (tmp$mean.to.beat<mean.y)
         {
           mean.y=tmp$mean.to.beat
           names.final[ii]=tmp$best.txt
           id.out=tmp$iidd
         }
       }
     }
    if(ncov==2)
     {
       for (i in 5:(ncol(x)-1))
       {
         for (k in (i+1):(ncol(x)))
         {
           if (is.ordinal[i-4] & is.ordinal[k-4]) tmp=ord.ord.surv.diff.paste(dat=x[,c(1:4,c(i,k))],mean.to.beat=mean.y,id.in=id.in)
           if (is.ordinal[i-4] & !is.ordinal[k-4]) tmp=nom.ord.surv.diff.paste(dat=x[,c(1:4,c(k,i))],mean.to.beat=mean.y,id.in=id.in)
           if (!is.ordinal[i-4] & is.ordinal[k-4]) tmp=nom.ord.surv.diff.paste(dat=x[,c(1:4,c(i,k))],mean.to.beat=mean.y,id.in=id.in)
           if (!is.ordinal[i-4] & !is.ordinal[k-4]) tmp=nom.nom.surv.diff.paste(dat=x[,c(1:4,c(i,k))],mean.to.beat=mean.y,id.in=id.in)
           if (tmp$mean.to.beat<(mean.y-.Machine$double.eps))
           {
             mean.y=tmp$mean.to.beat
             names.final[ii]=tmp$best.txt
             id.out=tmp$iidd
           }
         }
       }
     }
    # if pasting not possible, break
     if(names.final[ii]=='')
     {
       if (ii==1) return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
       break
     }

    if(mean.y<(mean.y.org))
     {
       utils::write.table(x,paste(tmp.path,'dat.paste.',ii,'.txt',sep=''),sep='\t')
       run.it=function(jjj,ii,tmp.path,n,ncov,is.ordinal,id.in,iter)
       {

library(PRIMsurvdiff)
         x.=utils::read.table(paste(tmp.path,'dat.paste.',ii,'.txt',sep=''),sep='\t')
         for (i in 5:ncol(x.)) x.[,i]=factor(x.[,i])
         perms=rep(NA,iter)
         grps=round(seq(1,1+iter,len=n+1))
         mean.y.org<-(mean(x.$event[which(x.$treat==1 & x.$ID %in% id.in)])/mean(x.$o.times[which(x.$treat==1 & x.$ID %in% id.in)]))/
          (mean(x.$event[which(x.$treat==0 & x.$ID %in% id.in)])/mean(x.$o.times[which(x.$treat==0 & x.$ID %in% id.in)]))
         for (kk in grps[jjj]:(grps[jjj+1]-1))
         {
           set.seed(kk+3*ii)
           perm.id=sample(c(1:nrow(x.)) %w/o% which(x.$ID %in% id.in))
           x.perm=x.
           x.perm[c(1:nrow(x.)) %w/o% which(x.$ID %in% id.in),1:4]=x.perm[perm.id,1:4]
           mean.y.perm=mean.y.org

           if(ncov==1)
           {
             for (i in 5:ncol(x.))
             {
               if (is.ordinal[i-4])  tmp=ord.surv.diff.paste(dat=x.perm[,c(1:4,i)],mean.to.beat=mean.y.perm,id.in=id.in)
               if (!is.ordinal[i-4]) tmp=nom.surv.diff.paste(dat=x.perm[,c(1:4,i)],mean.to.beat=mean.y.perm,id.in=id.in)

               if (tmp$mean.to.beat<mean.y.perm)
               {
                 mean.y.perm=tmp$mean.to.beat
               }
              }
           }
           if(ncov==2)
           {
             for (i in 5:(ncol(x.perm)-1))
             {
               for (k in (i+1):(ncol(x.perm)))
               {
                 if (is.ordinal[i-4] & is.ordinal[k-4]) 
                 tmp=ord.ord.surv.diff.paste(dat=x.perm[,c(1:4,c(i,k))],mean.to.beat=mean.y.perm,id.in=id.in)
                 if (is.ordinal[i-4] & !is.ordinal[k-4]) 
                 tmp=nom.ord.surv.diff.paste(dat=x.perm[,c(1:4,c(k,i))],mean.to.beat=mean.y.perm,id.in=id.in)
                 if (!is.ordinal[i-4] & is.ordinal[k-4]) 
                 tmp=nom.ord.surv.diff.paste(dat=x.perm[,c(1:4,c(i,k))],mean.to.beat=mean.y.perm,id.in=id.in)
                 if (!is.ordinal[i-4] & !is.ordinal[k-4]) 
                 tmp=nom.nom.surv.diff.paste(dat=x.perm[,c(1:4,c(i,k))],mean.to.beat=mean.y.perm,id.in=id.in)

                 if (tmp$mean.to.beat<mean.y.perm)
                 {
                   mean.y.perm=tmp$mean.to.beat
                 }
               }
             }
           }
           perms[kk]=mean.y.perm
         }
         write(perms[grps[jjj]:(grps[jjj+1]-1)],paste(tmp.path,'perms.paste.',ii,'.',jjj,'.txt',sep=''),sep='\t')
       }
       clusterApplyLB(cl=clust,1:length(clust),run.it,ii=ii,tmp.path=tmp.path,n=length(clust),ncov=ncov,
        is.ordinal=is.ordinal,id.in=id.in,iter=iter)

      while(length(list.files(tmp.path,pattern=paste('perms.paste.',ii,sep='')))<length(clust))
       {
         Sys.sleep(5)
       }
       unlink(paste(tmp.path,'dat.paste.',ii,'.txt',sep=''))
       perms=scan(paste(tmp.path,'perms.paste.',ii,'.',1,'.txt',sep=''),sep='\t',quiet=T)
       unlink(paste(tmp.path,'perms.paste.',ii,'.',1,'.txt',sep=''))
       if (length(clust)>1)
	   {
	     for (jjj in 2:length(clust))
         {
           tmp=scan(paste(tmp.path,'perms.paste.',ii,'.',jjj,'.txt',sep=''),sep='\t',quiet=T)
           perms=c(perms,tmp)
           unlink(paste(tmp.path,'perms.paste.',ii,'.',jjj,'.txt',sep=''))
         }
	   }
       p.value.final[ii]=mean(perms<mean.y)
       if (p.value.final[ii]<sig.level)
       {
         id.final=sort(c(id.out,id.in))
         id.in=id.final
       } else
         {
           if (ii==1) return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
           break
         }
     }
   }
   # output the final ids and term description
   return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
}
#' Internal pasting function for pasting term with 1 ordinal variable
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param id.in Indiciator variable for observations already in the current partition
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
ord.surv.diff.paste=function(dat,mean.to.beat,id.in)
{
  dat.out=dat[which(dat$ID %in% (dat$ID %w/o% id.in)),]
 # b1=data.table(dat.out)

  eve.in.0=sum(dat$event[which(dat$ID %in% id.in & dat$treat==0)])
  tim.in.0=sum(dat$o.times[which(dat$ID %in% id.in & dat$treat==0)])
  eve.in.1=sum(dat$event[which(dat$ID %in% id.in & dat$treat==1)])
  tim.in.1=sum(dat$o.times[which(dat$ID %in% id.in & dat$treat==1)])

#  a3=b1[,list(time=sum(o.times),event=sum(event)),by=b1[,4:5]]
 jnk1=summarize(dat.out[,'event'],dat.out[,4:5],sum)
 jnk2=summarize(dat.out[,'o.times'],dat.out[,4:5],sum)
 a3=merge(jnk2,jnk1)
 colnames(a3)[3:4]=c('time','event') 

 a3$haz=a3$event/a3$time
  a3=data.frame(a3)

  a3.0=a3[which(a3$treat==0),-1]
  a3.1=a3[which(a3$treat==1),-1]
  names(a3.0)[2:4]=paste(names(a3.0)[2:4],'.0',sep='')
  names(a3.1)[2:4]=paste(names(a3.1)[2:4],'.1',sep='')

  a4=merge(a3.0,a3.1,all=T)

  a4$time.0[is.na(a4$time.0)]=0
  a4$time.1[is.na(a4$time.1)]=0
  a4$event.0[is.na(a4$event.0)]=0
  a4$event.1[is.na(a4$event.1)]=0

  o=order(a4[,1])
  dd1=a4[o,]

  dd1$time.asc=cumsum(dd1$time.0+dd1$time.1)+tim.in.0+tim.in.1
  dd1$time.des=c(rev(cumsum(rev(dd1$time.0+dd1$time.1)))[-1],NA)+tim.in.0+tim.in.1

  dd1$time.1.asc=cumsum(dd1$time.1)+tim.in.1
  dd1$time.1.des=c(rev(cumsum(rev(dd1$time.1)))[-1],NA)+tim.in.1

  dd1$time.0.asc=cumsum(dd1$time.0)+tim.in.0
  dd1$time.0.des=c(rev(cumsum(rev(dd1$time.0)))[-1],NA)+tim.in.0

  dd1$event.1.asc=cumsum(dd1$event.1)+eve.in.1
  dd1$event.1.des=c(rev(cumsum(rev(dd1$event.1)))[-1],NA)+eve.in.1

  dd1$event.0.asc=cumsum(dd1$event.0)+eve.in.0
  dd1$event.0.des=c(rev(cumsum(rev(dd1$event.0)))[-1],NA)+eve.in.0

  dd1$haz.asc=(dd1$event.1.asc/dd1$time.1.asc)/(dd1$event.0.asc/dd1$time.0.asc)
  dd1$haz.des=(dd1$event.1.des/dd1$time.1.des)/(dd1$event.0.des/dd1$time.0.des)

  max.asc=min(dd1$haz.asc[which(dd1$haz.asc<mean.to.beat)])
  max.des=min(dd1$haz.des[which(dd1$haz.des<mean.to.beat)])

 if(max.asc!=(Inf) & max.des==(Inf))
  {
    id.=which(dd1==max.asc,arr.ind=T)
    id.=id.[which(colnames(dd1)[id.[,2]] %in% c('haz.asc','haz.des'))[1],]
    iidd=dat.out$ID[which(dat.out[,5] %in% dd1[1:id.[1],1])]
    best.txt=paste(colnames(dat.out)[5],'%in%',paste(dd1[1:id.[1],1],collapse=','))
    mean.to.beat=max.asc
  }

  if(max.asc==(Inf) & max.des!=(Inf))
  {
    id.=which(dd1==max.des,arr.ind=T)
    id.=id.[which(colnames(dd1)[id.[,2]] %in% c('haz.asc','haz.des'))[1],]
    iidd=dat.out$ID[which(dat.out[,5] %in% dd1[(1+id.[1]):nrow(dd1),1])]
    best.txt=paste(colnames(dat.out)[5],'%in%', paste(dd1[(1+id.[1]):nrow(dd1),1],collapse=','))
    mean.to.beat=max.des
  }

  if(max.asc!=(Inf) & max.des!=(Inf))
  {
    id.=which(dd1==min(max.asc,max.des),arr.ind=T)
    id.=id.[which(colnames(dd1)[id.[,2]] %in% c('haz.asc','haz.des'))[1],]
    if (colnames(dd1)[id.[2]]=='haz.des')
    {
      iidd=dat.out$ID[which(dat.out[,5] %in% dd1[(1+id.[1]):nrow(dd1),1])]
      best.txt=paste(colnames(dat.out)[5],'%in%', paste(dd1[(1+id.[1]):nrow(dd1),1],collapse=','))
    }

    if (colnames(dd1)[id.[2]]=='haz.asc')
    {
      iidd=dat.out$ID[which(dat.out[,5] %in% dd1[1:id.[1],1])]
      best.txt=paste(colnames(dat.out)[5],'%in%',paste(dd1[1:id.[1],1],collapse=','))
    }
    mean.to.beat=min(max.asc,max.des)
  }
  if (!exists('best.txt'))
  {
    best.txt=NULL
    iidd=NULL
  }
 return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}

#' Internal pasting function for pasting term with 1 nominal variable
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param id.in Indiciator variable for observations already in the current partition
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
nom.surv.diff.paste=function(dat,mean.to.beat,id.in)
{
  dat.out=dat[which(dat$ID %in% (dat$ID %w/o% id.in)),]
#  b1=data.table(dat.out)

  eve.in.0=sum(dat$event[which(dat$ID %in% id.in & dat$treat==0)])
  tim.in.0=sum(dat$o.times[which(dat$ID %in% id.in & dat$treat==0)])
  eve.in.1=sum(dat$event[which(dat$ID %in% id.in & dat$treat==1)])
  tim.in.1=sum(dat$o.times[which(dat$ID %in% id.in & dat$treat==1)])

 # a3=b1[,list(time=sum(o.times),event=sum(event)),by=b1[,4:5]]
  
 jnk1=summarize(dat.out[,'event'],dat.out[,4:5],sum)
 jnk2=summarize(dat.out[,'o.times'],dat.out[,4:5],sum)
 a3=merge(jnk2,jnk1)
 colnames(a3)[3:4]=c('time','event') 
  a3$haz=a3$event/a3$time
  a3=data.frame(a3)

  a3.0=a3[which(a3$treat==0),-1]
  a3.1=a3[which(a3$treat==1),-1]
  names(a3.0)[2:4]=paste(names(a3.0)[2:4],'.0',sep='')
  names(a3.1)[2:4]=paste(names(a3.1)[2:4],'.1',sep='')

  a4=merge(a3.0,a3.1,all=T)

  a4$time.0[is.na(a4$time.0)]=0
  a4$time.1[is.na(a4$time.1)]=0
  a4$event.0[is.na(a4$event.0)]=0
  a4$event.1[is.na(a4$event.1)]=0

  a4$haz.diff=((eve.in.1+a4$event.1)/(tim.in.1+a4$time.1))/((eve.in.0+a4$event.0)/(tim.in.0+a4$time.0))

  o=order(a4$haz.diff)
  dd1=a4[o,]

  dd1$cum.time.1=cumsum(dd1$time.1)+tim.in.1
  dd1$cum.time.0=cumsum(dd1$time.0)+tim.in.0
  dd1$cum.event.1=cumsum(dd1$event.1)+eve.in.1
  dd1$cum.event.0=cumsum(dd1$event.0)+eve.in.0

  dd1$cum.haz=(dd1$cum.event.1/dd1$cum.time.1)/(dd1$cum.event.0/dd1$cum.time.0)

  dd1$eval=as.numeric(rev(!duplicated(rev(dd1$cum.haz))))

  id.=which(dd1$cum.haz<mean.to.beat & dd1$eval==1)

  if (length(id.)>1) id.=id.[which.min(dd1$cum.haz[id.])]

   if(length(id.)>0)
  {
    iidd=NULL
    for (i in 1:id.) iidd=c(iidd,dat.out$ID[which(dat.out[,5]==dd1[i,1])])
    iidd=sort(iidd)
    best.txt=paste(names(dat.out)[5], '%in%',paste(dd1[1:id.,1],collapse=','))
    mean.to.beat=dd1$cum.haz[id.]
  }
  if (!exists('best.txt'))
  {
    best.txt=NULL
    iidd=NULL
  }
 return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}
