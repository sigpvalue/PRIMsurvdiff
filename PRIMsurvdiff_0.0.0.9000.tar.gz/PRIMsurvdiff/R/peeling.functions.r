#' Internal pasting function for peeling term with 1 ordinal and 1 nominal variable
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param n.needed Minimum length of cumulative follow-up time required for a subgroup to be valid
#' @param max.hr Maximum hazard ratio for outputted subgroup
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
nom.ord.surv.diff=function(dat,mean.to.beat,n.needed,max.hr)
{
  grouper=grp.sel(nlevels(dat[,6]))
  levs=levels(dat[,6])
  best.txt.store=''
  for (i in 1:length(grouper))
  {
    use.ids=which(dat[,6] %in% levs[grouper[[i]]])
    if (sum(dat$o.times[use.ids])>n.needed)
    {
       aa=peeling.surv.diff.int(dat=dat[,-6],mean.to.beat=mean.to.beat,n.needed=n.needed,group='nominal',use.ids=use.ids,max.hr=max.hr)
       if (!is.null(aa$iidd) & aa$mean.to.beat<mean.to.beat)
       {
         iidd.store=sort(aa$iidd)
         best.txt.store=paste(paste(colnames(dat)[6], '%in%',paste(levs[grouper[[i]]],collapse=','),sep=''),"^",aa$best.txt,sep='')
         mean.to.beat=aa$mean.to.beat
       }
    }
  }
  if (best.txt.store=='')
  {
    best.txt.store=NULL
    iidd.store=NULL
  }
  return(list(iidd=iidd.store,best.txt=best.txt.store,mean.to.beat=mean.to.beat))
}

#' Overall pasting function (not to be called)
#' 
#' @param x Matrix of variables under consideration for creating subgroups
#' @param n.needed Minimum length of cumulative follow-up time required for a subgroup to be valid
#' @param ncov Number of variables used to create each term that defines a subgroup 
#' @param sig.level Significance level (default = 0.05)
#' @param is.ordinal Indicator variable specifiying which column in \code{x} should be considered ordinal.
#' @param clust Cluster object created from parallel package
#' @param tmp.path Directory to store all intermediary files
#' @param iter Number of bootstrapped permutations to be run to assess the significance of each term
#' @param max.hr Maximum hazard ratio for outputted subgroup
#' @return id.final Output subgroups indicator
#' @return names.final Text definition of output subgroups
#' @return p.value.final P-value for output subgroups
#' @export

peel.PRIMsurvdiff<-function(x,n.needed,ncov,sig.level,is.ordinal,clust,tmp.path,iter,max.hr)
{
  # output matrices
  names.final<-rep('',50)
  p.value.final<-rep(NA,50)
  id.final=NULL
  # create up to 50 terms
  for (ii in 1:50)
  {
     # mean response

     mean.y.org=mean.y<-(mean(x$event[which(x$treat==1)])/mean(x$o.times[which(x$treat==1)]))/
     (mean(x$event[which(x$treat==0)])/mean(x$o.times[which(x$treat==0)]))
     if (is.na(mean.y.org)) return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
     if (ncov==1)
     {
       for (i in 5:ncol(x))
       {
         if (is.ordinal[i-4])  tmp=ord.surv.diff(dat=x[,c(1:4,i)],mean.to.beat=mean.y,n.needed=n.needed,max.hr=max.hr)
         if (!is.ordinal[i-4]) tmp=nom.surv.diff(dat=x[,c(1:4,i)],mean.to.beat=mean.y,n.needed=n.needed,max.hr=max.hr)

         if (tmp$mean.to.beat<(mean.y-.Machine$double.eps))
         {
           mean.y=tmp$mean.to.beat
           names.final[ii]=tmp$best.txt
           id.out=tmp$iidd
         }
       }
     }
     if(ncov==2)
     {
       for (i in 5:(ncol(x)-1))
       {
         for (k in (i+1):(ncol(x)))
         {
           if (is.ordinal[i-4] & is.ordinal[k-4]) tmp=ord.ord.surv.diff(dat=x[,c(1:4,c(i,k))],mean.to.beat=mean.y,n.needed=n.needed,max.hr=max.hr)
           if (is.ordinal[i-4] & !is.ordinal[k-4]) tmp=nom.ord.surv.diff(dat=x[,c(1:4,c(k,i))],mean.to.beat=mean.y,n.needed=n.needed,max.hr=max.hr)
           if (!is.ordinal[i-4] & is.ordinal[k-4]) tmp=nom.ord.surv.diff(dat=x[,c(1:4,c(i,k))],mean.to.beat=mean.y,n.needed=n.needed,max.hr=max.hr)
           if (!is.ordinal[i-4] & !is.ordinal[k-4]) 
           tmp=nom.nom.surv.diff(dat=x[,c(1:4,c(i,k))],mean.to.beat=mean.y,n.needed=n.needed,max.hr=max.hr)
           if (tmp$mean.to.beat<(mean.y-.Machine$double.eps))
           {
             mean.y=tmp$mean.to.beat
             names.final[ii]=tmp$best.txt
             id.out=tmp$iidd
           }
         }
       }
     }

     # if peeling not possible, break
     if(names.final[ii]=='')
     {
       if (ii==1) return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
       break
     }

      # if no improvement in mean response, break
     if (isTRUE(all.equal(mean.y,mean.y.org)))
     {
       if (ii==1) return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
       break
     }

     if(mean.y<(mean.y.org))
     {
	
       utils::write.table(x,paste(tmp.path,'dat.',ii,'.txt',sep=''),sep='\t')
       run.it=function(jjj,ii,tmp.path,n,ncov,is.ordinal,n.needed,iter,max.hr)
       {

	library(PRIMsurvdiff)	 
         x.=utils::read.table(paste(tmp.path,'dat.',ii,'.txt',sep=''),sep='\t')
         for (kk in 5:ncol(x.)) x.[,kk]=factor(x.[,kk])
         perms=rep(NA,iter)
         grps=round(seq(1,1+iter,len=n+1))
         mean.y.org<-(mean(x.$event[which(x.$treat==1)])/mean(x.$o.times[which(x.$treat==1)]))/
          (mean(x.$event[which(x.$treat==0)])/mean(x.$o.times[which(x.$treat==0)]))
         for (kk in grps[jjj]:(grps[jjj+1]-1))
         {
           set.seed(kk+3*ii)
           perm.id=sample(nrow(x.))
           x.perm=x.
           x.perm[,1:4]=x.perm[perm.id,1:4]
           mean.y.perm=mean.y.org
           if (ncov==1)
           {
             for (i in 5:ncol(x.))
             {
               if (is.ordinal[i-4])  tmp=ord.surv.diff(dat=x.perm[,c(1:4,i)],mean.to.beat=mean.y.perm,n.needed=n.needed,max.hr=max.hr)
               if (!is.ordinal[i-4]) tmp=nom.surv.diff(dat=x.perm[,c(1:4,i)],mean.to.beat=mean.y.perm,n.needed=n.needed,max.hr=max.hr)

               if (tmp$mean.to.beat<mean.y.perm)
               {
                 mean.y.perm=tmp$mean.to.beat
               }
             }
           }
           if(ncov==2)
           {
             for (i in 5:(ncol(x.)-1))
             {
               for (k in (i+1):(ncol(x.)))
               {
                 if (is.ordinal[i-4] & is.ordinal[k-4])   
                 tmp=ord.ord.surv.diff(dat=x.perm[,c(1:4,c(i,k))],mean.to.beat=mean.y.perm,n.needed=n.needed,max.hr=max.hr)
                 if (is.ordinal[i-4] & !is.ordinal[k-4])  
                 tmp=nom.ord.surv.diff(dat=x.perm[,c(1:4,c(k,i))],mean.to.beat=mean.y.perm,n.needed=n.needed,max.hr=max.hr)
                 if (!is.ordinal[i-4] & is.ordinal[k-4])  
                 tmp=nom.ord.surv.diff(dat=x.perm[,c(1:4,c(i,k))],mean.to.beat=mean.y.perm,n.needed=n.needed,max.hr=max.hr)
                 if (!is.ordinal[i-4] & !is.ordinal[k-4]) 
                 tmp=nom.nom.surv.diff(dat=x.perm[,c(1:4,c(i,k))],mean.to.beat=mean.y.perm,n.needed=n.needed,max.hr=max.hr)
                 if (tmp$mean.to.beat<mean.y.perm)
                 {
                   mean.y.perm=tmp$mean.to.beat
                 }
               }
             }
           }
         perms[kk]=mean.y.perm
         }
         write(perms[grps[jjj]:(grps[jjj+1]-1)],paste(tmp.path,'perms.',ii,'.',jjj,'.txt',sep=''),sep='\t')
       }
       clusterApplyLB(cl=clust,1:length(clust),run.it,ii=ii,tmp.path=tmp.path,n=length(clust),ncov=ncov,
        is.ordinal=is.ordinal,n.needed=n.needed,iter=iter,max.hr=max.hr)
       while(length(list.files(tmp.path,pattern=paste('perms.',ii,sep='')))<length(clust))
       {
         Sys.sleep(5)
       }
       unlink(paste(tmp.path,'dat.',ii,'.txt',sep=''))
       perms=scan(paste(tmp.path,'perms.',ii,'.',1,'.txt',sep=''),sep='\t',quiet=T)
       unlink(paste(tmp.path,'perms.',ii,'.',1,'.txt',sep=''))
       if (length(clust)>1)
	   {
	     for (jjj in 2:length(clust))
		 {
           tmp=scan(paste(tmp.path,'perms.',ii,'.',jjj,'.txt',sep=''),sep='\t',quiet=T)
           perms=c(perms,tmp)
           unlink(paste(tmp.path,'perms.',ii,'.',jjj,'.txt',sep=''))
		 }
       }
       p.value.final[ii]=mean(perms<mean.y)

       if (p.value.final[ii]<sig.level)
       {
         id.final=id.out
         x<-x[which(x$ID %in% id.out),,drop=FALSE]
       } else
         {
           if (ii==1) return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
           break
         }
     }
   }
   # output the final ids and term description
   return(list(names.final=names.final,id.final=id.final,p.value.final=p.value.final))
}
#' Internal pasting function for peeling term with 2 nominal variables
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param n.needed Minimum length of cumulative follow-up time required for a subgroup to be valid
#' @param max.hr Maximum hazard ratio for outputted subgroup
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
nom.nom.surv.diff=function(dat,mean.to.beat,n.needed,max.hr)
{
  dat$int=factor(paste(dat[,5],dat[,6],sep='^'))
  levs=levels(dat$int)
  info.=potent(nlevels(dat$int))$all

  if(is.null(info.))
  {
    best.txt=NULL
    iidd=NULL
    return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
  }

  out.info=matrix('',nrow(info.),2)
  out.num=matrix(NA,nrow(info.),4)
  colnames(out.info)=c('IN','OUT')
  colnames(out.num)=c('N_IN','N_OUT','HR_IN','HR_OUT')

  for (ii in 1:nrow(info.))
  {
    in.=levels(factor(dat[,7]))[which(info.[ii,]==1)]
    out.=levels(factor(dat[,7]))[which(info.[ii,]==0)]
    out.info[ii,1]=paste(in.,collapse='_')
    out.info[ii,2]=paste(out.,collapse='_')

    var.=rep(NA,nrow(dat))
    var.[which(dat[,7] %in% in.)]=1
    var.[which(dat[,7] %in% out.)]=0
    ns.=c(sum(dat$o.times[which(var.==1)]),sum(dat$o.times[which(var.==0)]))

    if (ns.[1]>=n.needed & ns.[2]>=n.needed)
    {
      out.num[ii,]=c(ns.,
      (sum(dat$event[which(var.==1 & dat$treat==1)])/sum(dat$o.times[which(var.==1 & dat$treat==1)]))/
      (sum(dat$event[which(var.==1 & dat$treat==0)])/sum(dat$o.times[which(var.==1 & dat$treat==0)])),
      (sum(dat$event[which(var.==0 & dat$treat==1)])/sum(dat$o.times[which(var.==0 & dat$treat==1)]))/
      (sum(dat$event[which(var.==0 & dat$treat==0)])/sum(dat$o.times[which(var.==0 & dat$treat==0)])))
    }
    if (ns.[1]<n.needed | ns.[2]<n.needed)
    {
      out.num[ii,]=c(ns.,
      (sum(dat$event[which(dat$treat==1)])/sum(dat$o.times[which(dat$treat==1)]))/
      (sum(dat$event[which(dat$treat==0)])/sum(dat$o.times[which(dat$treat==0)])),
      (sum(dat$event[which(dat$treat==1)])/sum(dat$o.times[which(dat$treat==1)]))/
      (sum(dat$event[which(dat$treat==0)])/sum(dat$o.times[which(dat$treat==0)])))
    }
  }

  out=data.frame(out.info,out.num)
  out$EVAL_IN=as.numeric(out$N_IN>=n.needed & out$N_OUT>=n.needed)
  out$EVAL_OUT=as.numeric(out$N_IN>=n.needed & out$N_OUT>=n.needed)

  out.in=out[,sort(c(grep('IN',colnames(out))))]
  out.out=out[,sort(c(grep('OUT',colnames(out))))]

  colnames(out.out)=colnames(out.in)=c('Subset','N','HR','Eval')
  out.fin=rbind(out.in,out.out)

  o=order(out.fin$HR)
  out.fin=out.fin[o,]
  sel=which(out.fin$Eval==1 & out.fin$HR<max.hr & out.fin$HR<mean.to.beat)[1]

  if (is.na(sel))
  {
    best.txt=NULL
    iidd=NULL
  }

  if(!is.na(sel))
  {
    iidd=dat$ID[which(dat[,7] %in% strsplit(as.character(out.fin[sel,1]),"_")[[1]])]
    best.txt=paste(paste(colnames(dat)[5:6],collapse='^'),'%in%',paste(strsplit(as.character(out.fin[sel,1]),"_")[[1]],collapse=','))
    mean.to.beat=out.fin[sel,3]
  }
  return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}
#' Internal wrapper function for peeling variable creation
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param n.needed Minimum length of cumulative follow-up time required for a subgroup to be valid
#' @param group Variable indicating whether a variable is ordinal or nominal
#' @param use.ids Observations under consideration 
#' @param max.hr Maximum hazard ratio for outputted subgroup
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
peeling.surv.diff.int=function(dat,mean.to.beat,n.needed,group,use.ids,max.hr)
{
  if (group=='ordered') info.=potent(nlevels(factor(dat[use.ids,5])))$ordered
  if (group=='nominal') info.=potent(nlevels(factor(dat[use.ids,5])))$all

  if(is.null(info.))
  {
    best.txt=NULL
    iidd=NULL
    return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
  }
  info.=rbind(info.,1-info.)

  out.info=matrix('',nrow(info.),2)
  out.num=matrix(NA,nrow(info.),3)
  colnames(out.info)=c('IN','OUT')
  colnames(out.num)=c('N_IN','N_OUT','HR')

  for (ii in 1:nrow(info.))
  {
    in.=levels(factor(dat[use.ids,5]))[which(info.[ii,]==1)]
    out.=levels(factor(dat[use.ids,5]))[which(info.[ii,]==0)]
    out.info[ii,1]=paste(in.,collapse='_')
    out.info[ii,2]=paste(out.,collapse='_')

    var.=rep(NA,nrow(dat))
    var.[intersect(use.ids,which(dat[,5] %in% in.))]=1
    var.[intersect(use.ids,which(dat[,5] %in% out.))]=0
    var.[-use.ids]=0
    ns.=c(sum(dat$o.times[which(var.==1)]),sum(dat$o.times[which(var.==0)]))

    if (ns.[1]>=n.needed & ns.[2]>=n.needed)
    {
      out.num[ii,]=c(ns.,(sum(dat$event[which(var.==1 & dat$treat==1)])/sum(dat$o.times[which(var.==1 & dat$treat==1)]))/
      (sum(dat$event[which(var.==1 & dat$treat==0)])/sum(dat$o.times[which(var.==1 & dat$treat==0)])))
    }
    if (ns.[1]<n.needed | ns.[2]<n.needed)
    {
      out.num[ii,]=c(ns.,(sum(dat$event[which(dat$treat==1)])/sum(dat$o.times[which(dat$treat==1)]))/
      (sum(dat$event[which(dat$treat==0)])/sum(dat$o.times[which(dat$treat==0)])))
    }
  }

  out=data.frame(out.info,out.num)
  out$EVAL_IN=as.numeric(out$N_IN>=n.needed & out$N_OUT>=n.needed)
  out.fin=out

  o=order(out.fin$HR)
  out.fin=out.fin[o,]
  sel=which(out.fin$EVAL_IN==1 & out.fin$HR<max.hr & out.fin$HR<mean.to.beat)[1]

  if (is.na(sel))
  {
    best.txt=NULL
    iidd=NULL
  }
  if(!is.na(sel))
  {
    iidd=dat$ID[intersect(use.ids,which(dat[,5] %in% strsplit(as.character(out.fin[sel,1]),"_")[[1]]))]
    best.txt=paste(colnames(dat)[5],'%in%',paste(strsplit(as.character(out.fin[sel,1]),"_")[[1]],collapse=','))
    mean.to.beat=out.fin[sel,5]
  }
  return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}

#' Internal pasting function for peeling term with 2 ordinal variables
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param n.needed Minimum length of cumulative follow-up time required for a subgroup to be valid
#' @param max.hr Maximum hazard ratio for outputted subgroup
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
ord.ord.surv.diff=function(dat,mean.to.beat,n.needed,max.hr)
{
  grouper=grp.sel(nlevels(dat[,6]))
  levs=levels(dat[,6])
  best.txt.store=''
  for (i in 1:length(grouper))
  {
    use.ids=which(dat[,6] %in% levs[grouper[[i]]])
    if (sum(dat$o.times[use.ids])>n.needed)
    {
       aa=peeling.surv.diff.int(dat=dat[,-6],mean.to.beat=mean.to.beat,n.needed=n.needed,group='ordered',use.ids=use.ids,max.hr=max.hr)
       if (!is.null(aa$iidd) & aa$mean.to.beat<mean.to.beat)
       {
         iidd.store=sort(aa$iidd)
         best.txt.store=paste(paste(colnames(dat)[6], '%in%',paste(levs[grouper[[i]]],collapse=','),sep=''),"^",aa$best.txt,sep='')
         mean.to.beat=aa$mean.to.beat
       }
    }
  }
  if (best.txt.store=='')
  {
    best.txt.store=NULL
    iidd.store=NULL
  }

  return(list(iidd=iidd.store,best.txt=best.txt.store,mean.to.beat=mean.to.beat))
}
#' Internal pasting function for peeling term with 1 nominal variable
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param n.needed Minimum length of cumulative follow-up time required for a subgroup to be valid
#' @param max.hr Maximum hazard ratio for outputted subgroup
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
nom.surv.diff=function(dat,mean.to.beat,n.needed,max.hr)
{
 # b1=data.table:data.table(dat)
#  a3=b1[,list(time=sum(o.times),event=sum(event)),by=b1[,4:5]]
 jnk1=summarize(dat[,'event'],dat[,4:5],sum)
 jnk2=summarize(dat[,'o.times'],dat[,4:5],sum)
a3=merge(jnk2,jnk1)
colnames(a3)[3:4]=c('time','event')

  a3$haz=a3$event/a3$time
  a3=data.frame(a3)
  a3.0=a3[which(a3$treat==0),-1]
  a3.1=a3[which(a3$treat==1),-1]
  names(a3.0)[2:4]=paste(names(a3.0)[2:4],'.0',sep='')
  names(a3.1)[2:4]=paste(names(a3.1)[2:4],'.1',sep='')

  a4=merge(a3.0,a3.1,all=T)

  a4$haz.0[is.na(a4$haz.0)]=sum(a4$event.0,na.rm=T)/sum(a4$time.0,na.rm=T)
  a4$haz.1[is.na(a4$haz.1)]=sum(a4$event.1,na.rm=T)/sum(a4$time.1,na.rm=T)

  a4$haz.diff=a4$haz.1/a4$haz.0

  o=order(a4$haz.diff)
  dd1=a4[o,]

  dd1$time.0[is.na(dd1$time.0)]=0
  dd1$time.1[is.na(dd1$time.1)]=0
  dd1$event.0[is.na(dd1$event.0)]=0
  dd1$event.1[is.na(dd1$event.1)]=0

  dd1$cum.time=cumsum(dd1$time.0+dd1$time.1)
  dd1$cum.time.1=cumsum(dd1$time.1)
  dd1$cum.time.0=cumsum(dd1$time.0)
  dd1$cum.event.1=cumsum(dd1$event.1)
  dd1$cum.event.0=cumsum(dd1$event.0)
  dd1$cum.haz=(dd1$cum.event.1/dd1$cum.time.1)/(dd1$cum.event.0/dd1$cum.time.0)

  dd1$eval=as.numeric(rev(!duplicated(rev(dd1$cum.haz))))

  id.=which(dd1$cum.time>n.needed & dd1$cum.haz<mean.to.beat & dd1$eval==1 & dd1$cum.haz<max.hr)
  id.=id.[which.min(dd1$cum.haz[id.])]
  a3=as.data.frame(a3)

  if(length(id.)>0)
  {
    iidd=NULL
    for (i in 1:id.) iidd=c(iidd,dat$ID[which(dat[,5]==dd1[i,1])])
    iidd=sort(iidd)
    best.txt=paste(names(dat)[5], '%in%',paste(dd1[1:id.,1],collapse=','))
    mean.to.beat=dd1$cum.haz[id.]
  }
  if (!exists('best.txt'))
  {
    best.txt=NULL
    iidd=NULL
  }
 return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}

#' Internal pasting function for peeling term with 1 ordinal variable
#' 
#' @param dat Data set under consideration
#' @param mean.to.beat Current hazard ratio for best subgroup
#' @param n.needed Minimum length of cumulative follow-up time required for a subgroup to be valid
#' @param max.hr Maximum hazard ratio for outputted subgroup
#' @return iidd Output subgroup indicator
#' @return best.txt Text definition of output subgroup
#' @return mean.to.beat Hazard ratio for output subgroup
#' @export
ord.surv.diff=function(dat,mean.to.beat,n.needed,max.hr)
{
#  b1=data.table::data.table(dat)
#  a3=b1[,list(time=sum(o.times),event=sum(event)),by=b1[,4:5]]
 jnk1=summarize(dat[,'event'],dat[,4:5],sum)
 jnk2=summarize(dat[,'o.times'],dat[,4:5],sum)
a3=merge(jnk2,jnk1)
colnames(a3)[3:4]=c('time','event')

  a3$haz=a3$event/a3$time
  a3=data.frame(a3)
  a3.0=a3[which(a3$treat==0),-1]
  a3.1=a3[which(a3$treat==1),-1]
  names(a3.0)[2:4]=paste(names(a3.0)[2:4],'.0',sep='')
  names(a3.1)[2:4]=paste(names(a3.1)[2:4],'.1',sep='')

  a4=merge(a3.0,a3.1,all=T)

  a4$haz.0[is.na(a4$haz.0)]=mean.to.beat
  a4$haz.1[is.na(a4$haz.1)]=mean.to.beat

  a4$haz.diff=a4$haz.1/a4$haz.0

  o=order(a4[,1])
  dd1=a4[o,]

  dd1$time.asc=cumsum(dd1$time.0+dd1$time.1)
  dd1$time.des=c(rev(cumsum(rev(dd1$time.0+dd1$time.1)))[-1],NA)

  dd1$time.1.asc=cumsum(dd1$time.1)
  dd1$time.1.des=c(rev(cumsum(rev(dd1$time.1)))[-1],NA)

  dd1$time.0.asc=cumsum(dd1$time.0)
  dd1$time.0.des=c(rev(cumsum(rev(dd1$time.0)))[-1],NA)

  dd1$event.1.asc=cumsum(dd1$event.1)
  dd1$event.1.des=c(rev(cumsum(rev(dd1$event.1)))[-1],NA)

  dd1$event.0.asc=cumsum(dd1$event.0)
  dd1$event.0.des=c(rev(cumsum(rev(dd1$event.0)))[-1],NA)

  dd1$haz.asc=(dd1$event.1.asc/dd1$time.1.asc)/(dd1$event.0.asc/dd1$time.0.asc)
  dd1$haz.des=(dd1$event.1.des/dd1$time.1.des)/(dd1$event.0.des/dd1$time.0.des)

  max.asc=min(dd1$haz.asc[which(dd1$haz.asc<mean.to.beat & dd1$time.asc>n.needed & dd1$haz.asc<max.hr)])
  max.des=min(dd1$haz.des[which(dd1$haz.des<mean.to.beat & dd1$time.des>n.needed & dd1$haz.des<max.hr)])

  if(max.asc!=(Inf) & max.des==(Inf))
  {
    id.=which(dd1==max.asc,arr.ind=T)
    id.=id.[which(colnames(dd1)[id.[,2]] %in% c('haz.asc','haz.des'))[1],]
    iidd=dat$ID[which(dat[,5] %in% dd1[1:id.[1],1])]
    best.txt=paste(colnames(dat)[5],'%in%',paste(dd1[1:id.[1],1],collapse=','))
    mean.to.beat=max.asc
  }

  if(max.asc==(Inf) & max.des!=(Inf))
  {
    id.=which(dd1==max.des,arr.ind=T)
    id.=id.[which(colnames(dd1)[id.[,2]] %in% c('haz.asc','haz.des'))[1],]
    iidd=dat$ID[which(dat[,5] %in% dd1[(1+id.[1]):nrow(dd1),1])]
    best.txt=paste(colnames(dat)[5],'%in%', paste(dd1[(1+id.[1]):nrow(dd1),1],collapse=','))
    mean.to.beat=max.des
  }

  if(max.asc!=(Inf) & max.des!=(Inf))
  {
    id.=which(dd1==min(max.asc,max.des),arr.ind=T)
    id.=id.[which(colnames(dd1)[id.[,2]] %in% c('haz.asc','haz.des'))[1],]
    if (colnames(dd1)[id.[2]]=='haz.des')
    {
      iidd=dat$ID[which(dat[,5] %in% dd1[(1+id.[1]):nrow(dd1),1])]
      best.txt=paste(colnames(dat)[5],'%in%', paste(dd1[(1+id.[1]):nrow(dd1),1],collapse=','))
    }

    if (colnames(dd1)[id.[2]]=='haz.asc')
    {
      iidd=dat$ID[which(dat[,5] %in% dd1[1:id.[1],1])]
      best.txt=paste(colnames(dat)[5],'%in%',paste(dd1[1:id.[1],1],collapse=','))
    }
    mean.to.beat=min(max.asc,max.des)
  }
  if (!exists('best.txt'))
  {
    best.txt=NULL
    iidd=NULL
  }
  return(list(iidd=iidd,best.txt=best.txt,mean.to.beat=mean.to.beat))
}
